# Test Results

## Summary

| Test family | Executed | Passed | Compliance |
|---|---|---|---|
| Connectivity | 6 | 6 | 100% |
| Security & legitimate flows | 4 | 4 | 100% |
| Micro-segmentation (DFW) | 5 | 5 | 100% |
| Access control | 3 | 3 | 100% |
| Logging | 2 | 2 | 100% |
| Resilience | 2 | 2 | 100% |
| **Total** | **22** | **22** | **100%** |

## Selected detailed results

### TC-07 — Micro-segmentation: web → vCenter blocked

| | |
|---|---|
| Expected | BLOCK |
| Observed | BLOCK — conforme |
| Evidence | `screenshots/07-dfw-blocked-flow-logs.png` |

### TC-08 — Legitimate flow: web → db on MySQL(3306)

| | |
|---|---|
| Expected | ALLOW |
| Observed | ALLOW — conforme |

### TC-12 — Policy persistence after vMotion

| | |
|---|---|
| Scenario | `role:web` VM migrated via vMotion to another host, then re-tested against `role:db` on port 3306 |
| Expected | ALLOW (rule is tag-based, should follow the VM) |
| Observed | ALLOW — conforme |
| Why it matters | Confirms the security model survives normal cluster operations (DRS-triggered migrations), not just a static snapshot of the network |

### TC-13 — Port scan containment

| | |
|---|---|
| Scenario | Port scan from a `role:web` VM against a `role:db` VM across ports 1–1024 |
| Expected | Only port 3306 visible, everything else filtered |
| Observed | Only port 3306 visible — conforme |

## Honest reading of the 100% figure

A 100% compliance rate should be read for what it actually demonstrates and no more: the deployed policy behaves exactly as designed, under tests designed by the same person who designed the policy, in a lab environment without production traffic or active adversarial testing. It is evidence of **functional correctness**, not a substitute for an independent security audit or a penetration test — both of which are explicitly listed as next steps in [`../documentation/06-zero-trust-model.md`](../documentation/06-zero-trust-model.md).
