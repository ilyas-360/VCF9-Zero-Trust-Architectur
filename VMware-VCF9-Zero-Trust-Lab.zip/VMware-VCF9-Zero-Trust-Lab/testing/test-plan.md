# Test Plan — 22 Scenarios Across 6 Families

## Methodology

Every test follows the same structure: a hypothesis is stated *before* execution (expected result, given the declared policy), then the observed result is checked against it. Each test was run at least twice — immediately after implementing the relevant rule, and again after a full lab restart — to rule out transient cluster state or DFW rule-propagation delay as a false positive/negative source.

## Full test index

| ID | Family | What it checks |
|---|---|---|
| TC-01 | Connectivity | Inter-host ping on the management segment |
| TC-02 | Connectivity | vmkping on the vMotion interface |
| TC-03 | Connectivity | vmkping on the vSAN interface |
| TC-04 | Connectivity | Correct IP assignment per NSX segment |
| TC-05 | Connectivity | vSAN replication between the 3 cluster hosts |
| TC-06 | Connectivity | Internal DNS resolution for VCF components |
| TC-07 | Micro-segmentation | `role:web` → `role:vcenter` (443) is blocked |
| TC-08 | Security & flows | `role:web` → `role:db` (3306) is allowed |
| TC-09 | Security & flows | A non-declared port between web and db is blocked |
| TC-10 | Micro-segmentation | Blocked flow between two VMs in the same `role:web` segment |
| TC-11 | Micro-segmentation | Untagged segment → `role:db` is blocked |
| TC-12 | Micro-segmentation | **Policy persists after vMotion** (tag-based, not IP-based) |
| TC-13 | Micro-segmentation | Port scan from web → db only reveals the one allowed port |
| TC-14 | Access control | Local ESXi authentication rejected under Lockdown mode |
| TC-15 | Access control | Service account rejected for an out-of-scope action |
| TC-16 | Access control | RBAC role correctly restricts an operational account |
| TC-17 | Security & flows | vSAN encryption at rest confirmed active |
| TC-18 | Security & flows | KMS key rotation confirmed functional |
| TC-19 | Logging | Blocked DFW events appear in the logs |
| TC-20 | Logging | Timestamps consistent across components |
| TC-21 | Resilience | VM restart after simulated host failure (vSphere HA) |
| TC-22 | Resilience | Tier-1 gateway failover (Active-Standby) |

Full results: [`test-results.md`](test-results.md).

## Why TC-12 (vMotion persistence) is the most important test in this set

Most of the other tests confirm that a static rule does what it says. TC-12 confirms something structurally more important: that the security policy is bound to **workload identity** (the NSX tag), not to network location. If this test had failed, it would mean the entire micro-segmentation model silently breaks the moment DRS migrates a VM to another host — which defeats the purpose of tag-based security groups. This is also why it's covered in detail with its own screenshot.
