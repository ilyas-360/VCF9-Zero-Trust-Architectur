# The Zero Trust Model Applied

## The five pillars and their VMware mechanism

| Zero Trust principle | VMware mechanism |
|---|---|
| Explicit verification | Identity Firewall + identity provider integration |
| Least privilege | NSX DFW micro-segmentation by dynamic security group |
| Management plane isolation | Management Domain separation, ESXi Lockdown mode |
| Encryption at rest | vSAN Data-at-Rest Encryption via KMS |
| Continuous visibility | Centralized NSX DFW flow logging |

This mapping is a practical interpretation of NIST SP 800-207 applied to a VMware stack — not an officially documented NIST-to-VMware mapping.

## Why these five have to work together

Each mechanism alone has a gap that another one closes:
- Identity Firewall without centralized logging can't detect an impersonation attempt after the fact
- Lockdown mode without identity provider integration hardens the host but says nothing about whether the accounts allowed through vCenter are themselves following least privilege
- Micro-segmentation without encryption still protects against lateral movement, but does nothing if the attacker gets physical access to a disk

Read together, this is a defense-in-depth design: each control is evaluated in [`testing/test-results.md`](../testing/test-results.md) against a specific scenario, not just asserted.

## A lightweight threat model (STRIDE-inspired)

| Category | Threat scenario | Mitigation |
|---|---|---|
| Spoofing | Admin identity impersonation | MFA, Identity Firewall |
| Tampering | Unauthorized DFW rule change | RBAC, scoped permissions |
| Repudiation | Untraceable admin action | Centralized logging |
| Information disclosure | Lateral movement to a sensitive segment | Deny-all micro-segmentation |
| Denial of service | Tier-0 Gateway saturation | Domain isolation, bounded blast radius |
| Elevation of privilege | Compromised local ESXi account | Lockdown mode |

## Honest limitations

This PoC demonstrates **functional feasibility**, not a production-grade security guarantee. Specifically out of scope:

- **No independent penetration test** — all 22 test scenarios were designed and executed by the same person who designed the security policy, which is a real source of confirmation bias
- **No load testing** — DFW behavior under production-representative traffic volume is unverified
- **No enterprise IAM/MFA integration** — Identity Firewall is validated at the RBAC/service-account level only
- **No automated SIEM correlation** — DFW logs were reviewed manually, not through an automated detection pipeline
- **Single-site only** — no multi-site replication or disaster recovery tested

## Roadmap to close these gaps

| Timeframe | Action |
|---|---|
| 0–3 months | Independent security review; confirm current DFW rule set holds under scrutiny |
| 3–9 months | Deploy on a dedicated physical cluster; measure performance under real load |
| 9–18 months | Enterprise IAM + MFA integration; SIEM correlation; multi-site / hybrid extension study (e.g. AWS VPC interconnect) |
