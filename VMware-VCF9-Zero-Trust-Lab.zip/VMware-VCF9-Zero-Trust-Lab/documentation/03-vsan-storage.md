# vSAN — Hyperconverged, Encrypted Storage

## What's deployed

A vSAN datastore aggregating local disks across the 3 ESXi hosts, with a Storage Policy enforcing FTT=1 (tolerates one host failure) and Data-at-Rest Encryption enabled.

```
esxi-mgmt-01 ─┐
esxi-mgmt-02 ─┼──► vSAN Datastore (encrypted)
esxi-mgmt-03 ─┘
```

## Why vSAN instead of a physical SAN

vSAN is software-defined storage: it pools local host disks into a single shared, distributed datastore, eliminating the dependency on a dedicated SAN appliance. Adding capacity becomes "add a host to the cluster" rather than a separate storage procurement process. This directly satisfies the functional requirement to remove the external SAN dependency (see [`01-context-and-requirements.md`](01-context-and-requirements.md)).

## Storage Policy-Based Management (SPBM)

Rather than configuring resilience and encryption disk-by-disk, vSAN applies a declarative **Storage Policy** per VM or group of VMs:

```json
{
  "policyName": "mgmt-domain-storage-policy",
  "failuresToTolerate": 1,
  "failureToleranceMethod": "RAID-1",
  "encryption": {
    "dataAtRest": true,
    "kmsCluster": "poc-kms-01"
  },
  "appliesTo": ["vcsa-01", "nsxmgr-01", "sddcmgr-01"]
}
```

Any future VM tagged as belonging to the management domain automatically inherits this policy — no manual per-disk configuration.

## Encryption key management

Data-at-Rest Encryption requires an external Key Management Server (KMS), connected via the standardized **KMIP** protocol. This matters operationally: key rotation and revocation are managed independently of the ESXi hosts' own lifecycle, which is what you want if you ever need to revoke access without touching the hosts themselves.

## FTT and the resilience/cost trade-off

| FTT | Hosts required | Replication factor |
|---|---|---|
| FTT=1 | 3 (minimum) | 2x |
| FTT=2 | 5 (minimum) | 3x+ |

This lab uses FTT=1, consistent with its 3-host footprint. A production deployment supporting critical workloads would typically use FTT=2 — documented here as a known gap, not glossed over.

## Screenshots referenced

- `screenshots/02-vsan-health.png` — Skyline Health status, aggregated datastore view
