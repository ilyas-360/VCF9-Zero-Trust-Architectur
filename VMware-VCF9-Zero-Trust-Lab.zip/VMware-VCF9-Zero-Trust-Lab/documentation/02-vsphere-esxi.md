# vSphere / ESXi — The Compute Foundation

## What's deployed

A 3-host ESXi cluster, managed by a vCenter Server Appliance (Tiny deployment), with vSphere HA and DRS enabled.

| Host | Role |
|---|---|
| esxi-mgmt-01/02/03 | Management Domain cluster |

## Why ESXi

ESXi is a type-1 (bare-metal) hypervisor: it runs directly on hardware with no general-purpose host OS underneath, which keeps its footprint small and its attack surface minimal compared to a type-2 hypervisor. Three features make it directly relevant to a Zero Trust design, not just "a place to run VMs":

- **Secure Boot (UEFI)** — guarantees the integrity of the hypervisor's boot chain
- **Lockdown mode** — disables direct local administration of the host; all administration must go through vCenter. This collapses the attack surface from "every host individually" to "one controlled management plane"
- **VMkernel isolation** — memory and CPU isolation between VMs (via hardware-assisted paging) is what makes it safe to co-locate workloads of different trust levels on the same physical hardware in the first place

## Cluster configuration

- **vSphere HA**: restarts VMs automatically on host failure
- **DRS**: automatic load balancing across the cluster
- **Lockdown mode**: enabled on every host, applied from vCenter (not configured locally per host)
- **Dedicated service account**: NSX integration uses a custom RBAC role scoped to exactly what it needs (inventory read, VM group management) — not the default administrator account

## Why a dedicated service account matters here

Using the default admin account for service-to-service integration is a common shortcut that quietly breaks least privilege. A custom role, scoped only to what NSX actually needs, means that if the NSX Manager credentials were ever compromised, the blast radius is bounded by that role's permissions — not full administrative control of vCenter.

## Screenshots referenced

- `screenshots/01-vcenter-cluster.png` — cluster view, 3 hosts attached and healthy
- `screenshots/09-vmotion-ha-drs.png` — HA/DRS configuration
