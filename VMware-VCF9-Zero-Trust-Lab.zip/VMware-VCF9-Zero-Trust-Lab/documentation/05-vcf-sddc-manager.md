# VMware Cloud Foundation & SDDC Manager

## What VCF actually adds

ESXi, vCenter, vSAN, and NSX can all be deployed and wired together manually — that's what the other docs in this repo describe. VCF's contribution is **SDDC Manager**: a single orchestration layer that automates the initial deployment (bring-up), enforces a compatibility matrix between component versions, and manages the lifecycle of the whole stack as one unit instead of four separately-patched products.

## Management Domain vs. Workload Domain

This separation is the single most important architectural decision in this project, and it's what makes the Zero Trust claim structural rather than just a firewall policy bolted on top:

| | Management Domain | Workload Domain |
|---|---|---|
| **Hosts** | vCenter, NSX Manager, SDDC Manager | Application VMs (web, db) |
| **Trust level** | Highest — compromise here means compromise of everything | Standard — isolated blast radius |
| **Network isolation** | Deny-all from Workload Domain by default | Isolated from Management by default |
| **Why it matters** | A compromised web server should never be able to reach vCenter directly | Application changes don't risk the control plane |

## Bring-up process

1. Deploy **Cloud Builder** appliance
2. Fill the **Deployment Parameter Workbook** (addressing, hostnames, licensing) — matching the addressing plan in [`policies/network-addressing-plan.md`](../policies/network-addressing-plan.md)
3. Validate (Cloud Builder checks DNS forward/reverse resolution, NTP consistency, and component versions *before* starting — most first-attempt bring-up failures trace back to DNS)
4. Bring-up creates the Management Domain
5. Create the Workload Domain from SDDC Manager, attaching it to the Workload Tier-1 gateway

## Version compatibility matrix used in this lab

| Component | Version |
|---|---|
| ESXi | 8.0 Update 3 |
| vCenter Server Appliance | 8.0 Update 3 |
| NSX | 4.2.x |
| vSAN | 8.0 U3 (integrated) |
| VMware Cloud Foundation | 9.0 |

SDDC Manager will refuse an upgrade that falls outside this matrix — which is itself a security control: it prevents an untested combination of component versions from being introduced into the environment.

## Screenshots referenced

- `screenshots/08-sddc-manager-dashboard.png` — SDDC Manager dashboard, both domains healthy
