# NSX — Software-Defined Networking & Micro-Segmentation

This is the component that actually makes the Zero Trust claim real. Everything else in this repo (compute, storage, orchestration) is infrastructure that NSX's Distributed Firewall then secures at the workload level.

## Topology

```
                    Tier-0 Gateway (NSX)
                   /                    \
   Tier-1 — Management              Tier-1 — Workload
    /      |       \                  /          \
seg-mgmt seg-vmotion seg-vsan     seg-web       seg-db
```

| Segment | Purpose |
|---|---|
| `seg-mgmt` | vCenter, NSX Manager, SDDC Manager |
| `seg-vmotion` | Live migration traffic |
| `seg-vsan` | Storage replication traffic |
| `seg-web` | Web application tier |
| `seg-db` | Database tier |

Full addressing plan: [`policies/network-addressing-plan.md`](../policies/network-addressing-plan.md).

## The Distributed Firewall (DFW) — the core mechanism

Unlike a traditional perimeter firewall sitting at one physical choke point, NSX's DFW is enforced **at the vNIC of every single VM**, inside the hypervisor itself. A packet is evaluated before it even reaches the virtual switch.

This matters because a physical firewall has a blind spot: it only sees traffic that actually passes through its one insertion point. East-west traffic between two VMs on the same host, same segment, never goes near it. The DFW has no such blind spot — every VM-to-VM flow is evaluated, regardless of physical location.

## Policy model: deny-all by default

```
Infrastructure section:
  allow-esxi-to-vcenter      role:esxi  → role:vcenter   HTTPS(443)   ALLOW
  block-app-to-vcenter       role:app-* → role:vcenter    Any         BLOCK

Application section:
  allow-web-to-db            role:web   → role:db        MySQL(3306) ALLOW
  block-web-to-vcenter       role:web   → role:vcenter    Any         BLOCK
  default-deny               Any        → Any             Any         BLOCK
```

Full rule set with explanations: [`policies/nsx-dfw-rules.md`](../policies/nsx-dfw-rules.md).

**Why deny-all rather than "allow-all with exceptions":** it costs more upfront documentation effort, but it matches the Zero Trust principle of implicit denial directly, and it means the rule set is auditable — anyone can read it and know exactly what's allowed and why, rather than trying to prove a negative.

## Security Groups: tag-based, not IP-based

VMs are grouped dynamically by tag (`role:web`, `role:db`, `role:vcenter`) rather than static IP address. This is what makes the policy survive a vMotion migration — the rule follows the VM's identity, not its temporary location in the cluster. This was explicitly tested (see [`testing/test-results.md`](../testing/test-results.md), TC-12).

## Identity Firewall & logging

- **Identity Firewall**: conditions certain administrative flows on authenticated user identity, not just source IP
- **DFW logging**: enabled per-rule at creation time, feeding the validation evidence in `testing/`

## Screenshots referenced

- `screenshots/03-nsx-topology.png` — NSX Manager topology view (Tier-0/Tier-1/segments, auto-generated)
- `screenshots/04-transport-nodes.png` — Transport Node preparation
- `screenshots/05-segments.png` — Segment configuration
- `screenshots/06-dfw-rule-creation.png` — DFW rule creation UI
- `screenshots/07-dfw-blocked-flow-logs.png` — Blocked flow in the DFW logs
