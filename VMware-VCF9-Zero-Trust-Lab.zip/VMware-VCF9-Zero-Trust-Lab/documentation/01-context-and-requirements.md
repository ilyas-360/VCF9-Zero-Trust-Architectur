# Context & Requirements

## The problem with perimeter security

Traditional virtualization security relies on a perimeter model: VLANs and physical firewalls control what crosses the network boundary, but traffic *inside* a VLAN is largely trusted by default. If a single workload is compromised, an attacker can move laterally to any other workload on the same segment with little resistance — because nothing inside the perimeter is actually re-verifying trust.

The existing environment this project targets looks like this:
- ESXi hosts + vCenter, managed as a standard cluster
- Physical SAN storage (no hyperconverged layer)
- VLAN-based segmentation, no software-defined micro-segmentation
- No fine-grained visibility into east-west (workload-to-workload) traffic

## The question this project answers

> How do you design a VMware Cloud Foundation 9 architecture that natively applies continuous verification, least privilege, and micro-segmentation — without creating so much operational overhead that teams route around it?

## Functional requirements

- Unified compute platform for heterogeneous workloads
- Hyperconverged storage (vSAN), removing dependency on external SAN
- Software-defined networking (NSX) — security policy changes without physical rewiring
- Centralized lifecycle orchestration (SDDC Manager) across all components

## Security requirements

- East-west micro-segmentation with least privilege enforced per flow, not just at the perimeter
- Explicit identity/context verification before authorizing a flow
- Centralized logging of all network flows, for anomaly detection
- Isolation of the management plane from the production plane
- Encryption of sensitive flows and data at rest

## Hardware constraints (why this matters for interpreting results)

A production VCF deployment typically requires 4+ dedicated physical hosts per management cluster. This lab runs on a constrained footprint (3 ESXi hosts), which affects two things directly:
- **vSAN fault tolerance** is set to FTT=1 (tolerates one host failure) rather than the higher levels recommended for production
- **HA/DRS behavior** is demonstrated functionally but not validated under production-representative load

This constraint is treated as a known limitation throughout the documentation, not hidden — see [`06-zero-trust-model.md`](06-zero-trust-model.md) for the full discussion.
