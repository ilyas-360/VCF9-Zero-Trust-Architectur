# NSX Distributed Firewall — Rule Set

Deny-all by default. Every allowed flow below is an explicit, documented exception.

## Infrastructure section

| Rule | Source | Destination | Service | Action | Why |
|---|---|---|---|---|---|
| `allow-esxi-to-vcenter` | `role:esxi` | `role:vcenter` | HTTPS (443) | ALLOW | Hosts must report to vCenter for management |
| `block-app-to-vcenter` | `role:app-*` | `role:vcenter` | Any | BLOCK | No application workload should ever reach the management plane directly |

## Application section

| Rule | Source | Destination | Service | Action | Why |
|---|---|---|---|---|---|
| `allow-web-to-db` | `role:web` | `role:db` | MySQL (3306) | ALLOW | The only legitimate application flow between tiers |
| `block-web-to-vcenter` | `role:web` | `role:vcenter` | Any | BLOCK | Defense in depth — redundant with the infrastructure-section block, enforced again at the application layer |
| `default-deny` | Any | Any | Any | BLOCK | Catch-all — anything not explicitly allowed above is denied |

## Declarative policy reference (as implemented)

```yaml
section: Infrastructure
  rule: allow-esxi-to-vcenter
    source: role:esxi
    destination: role:vcenter
    service: HTTPS(443)
    action: ALLOW
  rule: block-app-to-vcenter
    source: role:app-*
    destination: role:vcenter
    service: ANY
    action: BLOCK

section: Application
  rule: allow-web-to-db
    source: role:web
    destination: role:db
    service: MySQL(3306)
    action: ALLOW
  rule: block-web-to-vcenter
    source: role:web
    destination: role:vcenter
    service: ANY
    action: BLOCK
  rule: default-deny
    source: ANY
    destination: ANY
    service: ANY
    action: BLOCK
```

## Design decisions worth noting

**Evaluation order matters.** Rules are evaluated top-down, first match wins. The most specific rules come first; `default-deny` is always last, so nothing slips through by omission.

**Rule naming convention.** Every rule name follows `<action>-<source>-to-<destination>[-<detail>]` (e.g. `allow-web-to-db`). This isn't cosmetic — it means a future operator can understand a rule's intent from its name alone, without cross-referencing documentation, and it makes future API-driven rule automation straightforward.

**Alternative considered and rejected:** VLAN + physical ACLs could have provided coarse segmentation without NSX. Rejected because VLAN-based segmentation is bound to a subnet, not a workload identity — it can't follow a VM across a vMotion migration, and it doesn't meet the per-workload granularity requirement (see [`../documentation/01-context-and-requirements.md`](../documentation/01-context-and-requirements.md)).
