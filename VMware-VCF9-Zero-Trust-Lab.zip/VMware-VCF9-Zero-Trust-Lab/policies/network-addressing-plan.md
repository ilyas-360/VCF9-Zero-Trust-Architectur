# Network Addressing Plan

| NSX Segment | Address range | Purpose |
|---|---|---|
| `seg-mgmt` | 192.168.10.0/24 | vCenter, NSX Manager, SDDC Manager |
| `seg-vmotion` | 192.168.11.0/24 | Live VM migration traffic |
| `seg-vsan` | 192.168.12.0/24 | vSAN storage replication traffic |
| `seg-web` | 192.168.20.0/24 | Web application tier |
| `seg-db` | 192.168.21.0/24 | Database tier |

## Design notes

- A deliberately distinct private range (RFC 1918) was chosen to avoid overlap with any pre-existing corporate network, in case of future lab-to-production interconnection for demonstration purposes.
- Segments are organized **by function**, not by arbitrary subnet blocks — this keeps the micro-segmentation policy in [`nsx-dfw-rules.md`](nsx-dfw-rules.md) aligned with real traffic patterns rather than an artificial network boundary.
- `seg-vmotion` and `seg-vsan` are kept on dedicated segments, separate from management traffic, so that storage/migration traffic never shares a broadcast domain with administrative access.

## Gateway topology

```
Tier-0 Gateway (NSX)
 ├── Tier-1 — Management  → seg-mgmt, seg-vmotion, seg-vsan
 └── Tier-1 — Workload    → seg-web, seg-db
```

Both Tier-1 gateways currently run in **Active-Standby** mode, chosen for simpler failure diagnosis during the test campaign. Active-Active (covered in NSX Gateway HA documentation) would offer higher aggregate throughput and is the recommended mode for a production deployment with real traffic load.
