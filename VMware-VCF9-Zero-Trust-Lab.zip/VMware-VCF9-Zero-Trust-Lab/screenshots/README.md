# Screenshots

Drop your captures here using the exact filenames below — every one is already linked from a documentation file, so using these names means you don't have to touch any `.md` file after adding the images.

| Filename | Referenced in | Content |
|---|---|---|
| `01-vcenter-cluster.png` | `documentation/02-vsphere-esxi.md` | vSphere Client — cluster + 3 hosts attached to vCenter |
| `02-vsan-health.png` | `documentation/03-vsan-storage.md` | vSAN Skyline Health + aggregated datastore |
| `03-nsx-topology.png` | `documentation/04-nsx-networking-security.md` | NSX Manager — auto-generated Tier-0/Tier-1/segment topology |
| `04-transport-nodes.png` | `documentation/04-nsx-networking-security.md` | Transport Node preparation screen |
| `05-segments.png` | `documentation/04-nsx-networking-security.md` | NSX segment configuration |
| `06-dfw-rule-creation.png` | `documentation/04-nsx-networking-security.md` | DFW rule creation UI, pre-publish |
| `07-dfw-blocked-flow-logs.png` | `documentation/04-nsx-networking-security.md`, `testing/test-results.md` | DFW logs showing a blocked flow |
| `08-sddc-manager-dashboard.png` | `documentation/05-vcf-sddc-manager.md` | SDDC Manager — both domains healthy |
| `09-vmotion-ha-drs.png` | `documentation/02-vsphere-esxi.md` | HA/DRS cluster configuration |

Keep this naming convention if you add more — numeric prefix matching build order, short kebab-case description.
